package com.payment.central.service;

import com.payment.central.client.AddressServiceClient;
import com.payment.central.client.CommissionServiceClient;
import com.payment.central.model.TransferRequest;
import com.payment.central.model.TransferResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class PaymentService {

    @Autowired
    private AddressServiceClient addressServiceClient;

    @Autowired
    private CommissionServiceClient commissionServiceClient;

    private final ConcurrentHashMap<String, TransferResponse> transactions = new ConcurrentHashMap<>();

    public TransferResponse processTransfer(TransferRequest request) {
        String transactionId = UUID.randomUUID().toString();
        
        try {

            String fromAccount = resolveAccount(request.getFromIdentifier());
            String toAccount = resolveAccount(request.getToIdentifier());

            BigDecimal commission = commissionServiceClient.calculateCommission(
                fromAccount, toAccount, request.getAmount());

            TransferResponse response = new TransferResponse();
            response.setTransactionId(transactionId);
            response.setStatus("SUCCESS");
            response.setAmount(request.getAmount());
            response.setCommission(commission);
            response.setTotalAmount(request.getAmount().add(commission));
            response.setFromAccount(fromAccount);
            response.setToAccount(toAccount);
            response.setTimestamp(LocalDateTime.now());
            response.setMessage("Transfer completed successfully");

            transactions.put(transactionId, response);

            return response;

        } catch (Exception e) {
            TransferResponse errorResponse = new TransferResponse(transactionId, "FAILED", e.getMessage());
            transactions.put(transactionId, errorResponse);
            throw new RuntimeException(e.getMessage());
        }
    }

    public TransferResponse getTransactionStatus(String transactionId) {
        TransferResponse response = transactions.get(transactionId);
        if (response == null) {
            throw new RuntimeException("Transaction not found");
        }
        return response;
    }

    private String resolveAccount(String identifier) {

        if (identifier.startsWith("+") || identifier.matches("\\d+")) {
            return addressServiceClient.getAccountByPhone(identifier);
        }

        return identifier;
    }
}
