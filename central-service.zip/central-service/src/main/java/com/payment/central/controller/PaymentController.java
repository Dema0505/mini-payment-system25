package com.payment.central.controller;

import com.payment.central.model.TransferRequest;
import com.payment.central.model.TransferResponse;
import com.payment.central.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "*")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/transfer")
    public ResponseEntity<TransferResponse> transfer(@Valid @RequestBody TransferRequest request) {
        try {
            TransferResponse response = paymentService.processTransfer(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            TransferResponse errorResponse = new TransferResponse();
            errorResponse.setStatus("FAILED");
            errorResponse.setMessage("Transfer failed: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/status/{transactionId}")
    public ResponseEntity<TransferResponse> getTransactionStatus(@PathVariable String transactionId) {
        try {
            TransferResponse response = paymentService.getTransactionStatus(transactionId);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            TransferResponse errorResponse = new TransferResponse();
            errorResponse.setStatus("NOT_FOUND");
            errorResponse.setMessage("Transaction not found");
            return ResponseEntity.notFound().build();
        }
    }
}
