package com.payment.central.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;

public class TransferRequest {
    @NotNull
    private String fromIdentifier;
    
    @NotNull
    private String toIdentifier;
    
    @NotNull
    @Positive
    private BigDecimal amount;
    
    private String description;

    public TransferRequest() {}

    public TransferRequest(String fromIdentifier, String toIdentifier, BigDecimal amount, String description) {
        this.fromIdentifier = fromIdentifier;
        this.toIdentifier = toIdentifier;
        this.amount = amount;
        this.description = description;
    }

    public String getFromIdentifier() { return fromIdentifier; }
    public void setFromIdentifier(String fromIdentifier) { this.fromIdentifier = fromIdentifier; }

    public String getToIdentifier() { return toIdentifier; }
    public void setToIdentifier(String toIdentifier) { this.toIdentifier = toIdentifier; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
