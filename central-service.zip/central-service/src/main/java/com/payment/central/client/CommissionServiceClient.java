package com.payment.central.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

@FeignClient(name = "commission-service", url = "${commission.service.url:http://localhost:8083}")
public interface CommissionServiceClient {

    @GetMapping("/api/commission/calculate")
    BigDecimal calculateCommission(
            @RequestParam("fromAccount") String fromAccount,
            @RequestParam("toAccount") String toAccount,
            @RequestParam("amount") BigDecimal amount
    );
}
